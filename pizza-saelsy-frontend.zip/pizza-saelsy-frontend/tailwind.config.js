module.exports = {
  content: [
    "./src/**/*.{html,ts}",
  ],
  theme: {
    extend: {},
    colors: {
      'nav--color': '#1F2937',
      'nav--text-color': '#FFFFFF',
      'nav__btn--active': '#BE123C',
      'nav__btn--hover': '#F43F5E',
      'text-color--dark': '#1F2937',
      'bg--default': '#eceef5',
      'focus--default': '#1F2937',
      'card--color': '#ffffff',
      'btn--color': '#E5E7EB',
      'btn--text-color': '#1E293B',
      'btn--hover': '#1E293B',
      'btn--hover--text-color': '#FFFFFF',
    },
  },
  plugins: [],
}
