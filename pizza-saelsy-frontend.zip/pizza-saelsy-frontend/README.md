# Pizza SaElSy 🍕 - Frontend
This is the frontend repository of the project "Pizza Mobile".  
The frontend will be done with Angular. The goal is to communicate with an API made with Django to build this "Pizza Mobile" application.

## Installation

### Clone the project
```
git clone https://gitlab.epai-ict.ch/nicolets/pizza-saelsy-frontend.git && cd pizza-saelsy-frontend.git
```

### Install dependencies
```
npm install
```

## Development server

Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`. The app will automatically reload if you change any of the source files.

## Create a component
Run 'ng generate component xxx'
