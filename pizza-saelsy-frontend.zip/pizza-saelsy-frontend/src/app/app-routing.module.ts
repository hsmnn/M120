import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CaisseComponent } from "./pages/caisse/caisse.component";
import {CuisineComponent} from "./pages/cuisine/cuisine.component";
import {LivraisonComponent} from "./pages/livraison/livraison.component";
import {AdminComponent} from "./pages/admin/admin.component";

const routes: Routes = [
  { path: '', redirectTo: 'caisse', pathMatch: 'full' },
  { path: 'caisse', component: CaisseComponent },
  { path: 'cuisine', component: CuisineComponent },
  { path: 'livraison', component: LivraisonComponent },
  { path: 'admin', component: AdminComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
