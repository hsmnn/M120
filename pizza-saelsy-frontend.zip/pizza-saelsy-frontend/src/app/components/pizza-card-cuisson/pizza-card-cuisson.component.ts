import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pizza-card-cuisson',
  templateUrl: './pizza-card-cuisson.component.html',
  styleUrls: ['./pizza-card-cuisson.component.scss']
})
export class PizzaCardCuissonComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
