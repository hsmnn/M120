import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PizzaCardCuissonComponent } from './pizza-card-cuisson.component';

describe('PizzaCardCuissonComponent', () => {
  let component: PizzaCardCuissonComponent;
  let fixture: ComponentFixture<PizzaCardCuissonComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PizzaCardCuissonComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PizzaCardCuissonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
