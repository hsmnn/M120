import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PizzaCardPreparationComponent } from './pizza-card-preparation.component';

describe('PizzaCardPreparationComponent', () => {
  let component: PizzaCardPreparationComponent;
  let fixture: ComponentFixture<PizzaCardPreparationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PizzaCardPreparationComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PizzaCardPreparationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
