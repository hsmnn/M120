import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pizza-card-preparation',
  templateUrl: './pizza-card-preparation.component.html',
  styleUrls: ['./pizza-card-preparation.component.scss']
})
export class PizzaCardPreparationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
