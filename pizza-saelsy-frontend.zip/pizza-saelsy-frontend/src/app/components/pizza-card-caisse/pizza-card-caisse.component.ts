import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pizza-card-caisse',
  templateUrl: './pizza-card-caisse.component.html',
  styleUrls: ['./pizza-card-caisse.component.scss']
})
export class PizzaCardCaisseComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
