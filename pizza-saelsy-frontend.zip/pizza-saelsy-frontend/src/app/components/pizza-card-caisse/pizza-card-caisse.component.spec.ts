import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PizzaCardCaisseComponent } from './pizza-card-caisse.component';

describe('PizzaCardCaisseComponent', () => {
  let component: PizzaCardCaisseComponent;
  let fixture: ComponentFixture<PizzaCardCaisseComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PizzaCardCaisseComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PizzaCardCaisseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
