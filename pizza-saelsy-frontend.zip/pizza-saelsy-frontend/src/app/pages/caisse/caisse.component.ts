import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-caisse',
  templateUrl: './caisse.component.html',
  styleUrls: ['./caisse.component.scss']
})
export class CaisseComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
