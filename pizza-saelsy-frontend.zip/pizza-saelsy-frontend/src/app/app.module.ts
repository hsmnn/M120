import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavbarComponent } from './components/navbar/navbar.component';
import { CaisseComponent } from './pages/caisse/caisse.component';
import { CuisineComponent } from './pages/cuisine/cuisine.component';
import { LivraisonComponent } from './pages/livraison/livraison.component';
import { AdminComponent } from './pages/admin/admin.component';
import { PizzaCardCaisseComponent } from './components/pizza-card-caisse/pizza-card-caisse.component';
import { PizzaCardCuissonComponent } from './components/pizza-card-cuisson/pizza-card-cuisson.component';
import { PizzaCardPreparationComponent } from './components/pizza-card-preparation/pizza-card-preparation.component';

@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    CaisseComponent,
    CuisineComponent,
    LivraisonComponent,
    AdminComponent,
    PizzaCardCaisseComponent,
    PizzaCardCuissonComponent,
    PizzaCardPreparationComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
