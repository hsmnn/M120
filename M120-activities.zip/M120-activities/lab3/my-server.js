const express = require('express')
const app = express()

app.get('/', function (req, res) {
  res.send(
      '<h1>M120 - Lab 3</h1>' +
      '<p>Cette ressource dynamique est servie par le serveur HTTP <code>my-server.js</code></p>' +
      '<p>Aller à : <a href="/static/my-page.html">msy-page.html</a></p>')
})

app.use('/static', express.static(__dirname + '/public'))

app.listen(3000, function () {
  console.log('Server address: http://127.0.0.1:3000/')
  console.log('Server running... press ctrl-c to stop.')
})