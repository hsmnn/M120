// Affecte une procédure à une variable locale.
const mySuperFunction = function () {
    // Affecte la valeur d’une expression lambda (une fonction
    // anonyme) à une variable locale.
    const sqrt = function (value) {
      return Math.pow(value, 0.5)
    }
  
    // Calcule le carré de 2 et écrit le résultat dans la console.
    console.log('La racine de deux est : ', sqrt(2))
  }
  
  // Invoke l’exécution de la procédure. Les parenthèses sont vides, car
  // la procédure n’a pas d’arguments, mais elle indique que la fonction
  // doit être appelée.
  mySuperFunction()
  
  // N’a pas d’effet (n’importe quelle expression est une instruction).
  mySuperFunction
  
  // Génère une exception, la fonction sqrt n’est pas définie en dehors
  // de la fonction mySuperFunction.
  console.log('La racine de deux est : ', sqrt(2))