const points = [40, 100, 1, 5, 25, 10]

// Crée un objet de type fonction et
// affecte la référence à la variable
// compare.
const compare = function (a, b) {
  return a - b
}

console.log(points)

// Appelle la méthode sort en passant
// la variable compare qui référence
// la fonction de comparaison.
points.sort(compare)

console.log(points)