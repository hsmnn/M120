// La partie droite de l’affectation (depuis le mot clé
// function à l’accolade fermée) est une expression lambda.
// Cette expression a pour effet de créer un objet de type 
// function. Après l’exécution de l’affection, la variable 
// square contient une référence à la fonction.
const square = function (value) {
    return value * value
  }
  
  // On peut vérifier que la variable square est bien de type
  // function à l’aide du mot clé typeof.
  console.log('Le type de la variable square est : ' + typeof (square))
  
  // Applique la fonction square à la valeur 2 et affiche
  // le résultat dans la console.
  console.log('Le carré de 2 est : ' + square(2))
  
  // L’appel d’une fonction avec la syntaxe classique square(2)
  // est un raccourci pour appeler la méthode apply de l’objet
  // de type function. Le premier argument est la valeur de
  // this; une fonction globale est une méthode de l’objet
  // Global référencé par la variable window. Le second argument
  // est un tableau contenant les paramètres effectifs de la
  // fonction.
  console.log('Le carré de 2 est : ' + square.apply(window, [2]))