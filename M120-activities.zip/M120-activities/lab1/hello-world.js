// Déclare la variable myString et initialise sa valeur.
const myString = 'Hello world !'

// Déclare la variable de boucle avec let, car sa valeur
// doit pouvoir être modifiée.
for (let i = 0; i < 4; i += 1) {
  // Affiche la concaténation de plusieurs chaînes dans la console
  console.log(myString + ' (' + (i + 1) + 'x)')

  console.log('Le type de i est : ' + typeof (i) + ', le type de myString est : ' + typeof (myString))
}
console.log('\n\nExtérieur de la boucle')

// La variable i n’est pas définie en dehors de la boucle,
// son type est donc undefined.
console.log('Le type de i est : ' + typeof (i) + ', le type de myString est : ' + typeof (myString))

// Appel la fonction référencée par la variable square.
const val = 4
const res = square(val)
console.log('Le carré de ' + val + ' est : ' + res)