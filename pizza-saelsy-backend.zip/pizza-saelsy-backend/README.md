# Pizza SaElSy 🍕 - Backend
This is the backend repository of the project "Pizza Mobile".  
The backend will be done with the Python framework Django. The goal is to make an API that will be accessed by our frontend in Angular.

## Installation

### Clone the project
```
git clone https://gitlab.epai-ict.ch/nicolets/pizza-saelsy-backend.git && cd pizza-saelsy-backend.git
```

### Start container
```
docker-compose up
```